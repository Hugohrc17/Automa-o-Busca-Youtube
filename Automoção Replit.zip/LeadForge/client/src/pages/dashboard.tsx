import { useState } from "react";
import { Gamepad2, Circle, Settings } from "lucide-react";
import SearchTab from "@/components/search-tab";
import ChannelsTab from "@/components/channels-tab";
import StatisticsTab from "@/components/statistics-tab";
import ExportTab from "@/components/export-tab";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("search");

  const tabs = [
    { id: "search", label: "Search Leads", icon: "fas fa-search" },
    { id: "channels", label: "Found Channels", icon: "fas fa-users" },
    { id: "statistics", label: "Statistics", icon: "fas fa-chart-bar" },
    { id: "export", label: "Export Data", icon: "fas fa-download" },
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case "search":
        return <SearchTab />;
      case "channels":
        return <ChannelsTab />;
      case "statistics":
        return <StatisticsTab />;
      case "export":
        return <ExportTab />;
      default:
        return <SearchTab />;
    }
  };

  return (
    <div className="bg-slate-50 min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-primary text-white p-2 rounded-lg">
                <Gamepad2 className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-900">YouTube Gaming Lead Capture</h1>
                <p className="text-sm text-slate-500">Find gaming channels for video editing services</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-slate-600">
                <Circle className="h-3 w-3 text-accent fill-current" />
                <span>System Active</span>
              </div>
              <button className="text-slate-400 hover:text-slate-600 transition-colors">
                <Settings className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Tab Navigation */}
      <nav className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? "border-primary text-primary"
                    : "border-transparent text-slate-500 hover:text-slate-700"
                }`}
              >
                <i className={`${tab.icon} mr-2`}></i>
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderTabContent()}
      </main>
    </div>
  );
}

import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Users, Target, Send, CheckCircle, TrendingUp, TrendingDown } from "lucide-react";

export default function StatisticsTab() {
  // Fetch statistics
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/statistics"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="text-lg font-medium text-slate-900 mb-2">Loading Statistics...</div>
          <div className="text-sm text-slate-500">Please wait while we gather your data</div>
        </div>
      </div>
    );
  }

  const responseRate = stats?.contactedChannels > 0 
    ? Math.round((stats.convertedChannels / stats.contactedChannels) * 100) 
    : 0;

  const conversionRate = stats?.targetChannels > 0
    ? Math.round((stats.convertedChannels / stats.targetChannels) * 100)
    : 0;

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Total Channels</p>
                <p className="text-2xl font-bold text-slate-900">{stats?.totalChannels || 0}</p>
                <p className="text-xs text-accent flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +12% from last week
                </p>
              </div>
              <div className="bg-primary/10 p-3 rounded-lg">
                <Users className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Target Range</p>
                <p className="text-2xl font-bold text-slate-900">{stats?.targetChannels || 0}</p>
                <p className="text-xs text-accent">
                  {stats?.totalChannels > 0 
                    ? Math.round((stats.targetChannels / stats.totalChannels) * 100)
                    : 0}% of total
                </p>
              </div>
              <div className="bg-accent/10 p-3 rounded-lg">
                <Target className="h-6 w-6 text-accent" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Contacted</p>
                <p className="text-2xl font-bold text-slate-900">{stats?.contactedChannels || 0}</p>
                <p className="text-xs text-warning">{responseRate}% response rate</p>
              </div>
              <div className="bg-warning/10 p-3 rounded-lg">
                <Send className="h-6 w-6 text-warning" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Converted</p>
                <p className="text-2xl font-bold text-slate-900">{stats?.convertedChannels || 0}</p>
                <p className="text-xs text-accent">{conversionRate}% conversion rate</p>
              </div>
              <div className="bg-accent/10 p-3 rounded-lg">
                <CheckCircle className="h-6 w-6 text-accent" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Niche Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Distribution by Niche</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {stats?.nicheDistribution?.map((item) => {
              const percentage = stats.totalChannels > 0 
                ? Math.round((item.count / stats.totalChannels) * 100)
                : 0;
              
              const getColor = (niche: string) => {
                switch (niche) {
                  case "minecraft": return "bg-green-500";
                  case "roblox": return "bg-blue-500";
                  case "fortnite": return "bg-purple-500";
                  default: return "bg-slate-500";
                }
              };

              return (
                <div key={item.niche}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${getColor(item.niche)}`}></div>
                      <span className="text-sm font-medium text-slate-700 capitalize">
                        {item.niche.replace("_", " ")}
                      </span>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-semibold text-slate-900">{item.count}</div>
                      <div className="text-xs text-slate-500">{percentage}%</div>
                    </div>
                  </div>
                  <Progress value={percentage} className="h-2" />
                </div>
              );
            }) || (
              <div className="text-center py-4 text-slate-500">
                No data available yet
              </div>
            )}
          </CardContent>
        </Card>

        {/* Contact Status Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle>Contact Status Breakdown</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {stats?.statusDistribution?.map((item) => {
              const percentage = stats.targetChannels > 0 
                ? Math.round((item.count / stats.targetChannels) * 100)
                : 0;
              
              const getStatusInfo = (status: string) => {
                switch (status) {
                  case "not_contacted":
                    return { label: "Not Contacted", color: "bg-slate-400" };
                  case "contacted":
                    return { label: "Contacted", color: "bg-warning" };
                  case "responded":
                    return { label: "Responded", color: "bg-accent" };
                  case "converted":
                    return { label: "Converted", color: "bg-primary" };
                  default:
                    return { label: status, color: "bg-slate-400" };
                }
              };

              const statusInfo = getStatusInfo(item.status);

              return (
                <div key={item.status}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-slate-700">{statusInfo.label}</span>
                    <span className="text-sm font-semibold text-slate-900">{item.count} channels</span>
                  </div>
                  <Progress value={percentage} className="h-2" />
                  <p className="text-xs text-slate-500 mt-1">
                    {percentage}% of target channels
                    {item.status === "responded" && stats.contactedChannels > 0 && (
                      <span> • {Math.round((item.count / stats.contactedChannels) * 100)}% response rate</span>
                    )}
                    {item.status === "converted" && stats.contactedChannels > 0 && (
                      <span> • {Math.round((item.count / stats.contactedChannels) * 100)}% conversion rate</span>
                    )}
                  </p>
                </div>
              );
            }) || (
              <div className="text-center py-4 text-slate-500">
                No contact data available yet
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Performance Metrics */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Performance Trends</CardTitle>
          <Select defaultValue="7days">
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 days</SelectItem>
              <SelectItem value="30days">Last 30 days</SelectItem>
              <SelectItem value="90days">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 bg-accent/10 rounded-lg">
              <div className="text-2xl font-bold text-accent mb-1">{responseRate}%</div>
              <div className="text-sm text-slate-600">Response Rate</div>
              <div className="text-xs text-accent mt-1 flex items-center justify-center">
                <TrendingUp className="h-3 w-3 mr-1" />
                +2.1% from last week
              </div>
            </div>
            
            <div className="text-center p-4 bg-primary/10 rounded-lg">
              <div className="text-2xl font-bold text-primary mb-1">{conversionRate}%</div>
              <div className="text-sm text-slate-600">Conversion Rate</div>
              <div className="text-xs text-primary mt-1 flex items-center justify-center">
                <TrendingUp className="h-3 w-3 mr-1" />
                +0.8% from last week
              </div>
            </div>
            
            <div className="text-center p-4 bg-warning/10 rounded-lg">
              <div className="text-2xl font-bold text-warning mb-1">3.2 days</div>
              <div className="text-sm text-slate-600">Avg Response Time</div>
              <div className="text-xs text-warning mt-1 flex items-center justify-center">
                <TrendingDown className="h-3 w-3 mr-1" />
                -0.5 days from last week
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

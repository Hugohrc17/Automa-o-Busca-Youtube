import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Search, ExternalLink, ChevronLeft, ChevronRight } from "lucide-react";
import type { Channel } from "@shared/schema";

export default function ChannelsTab() {
  const { toast } = useToast();
  const [filters, setFilters] = useState({
    niche: "all",
    contactStatus: "all",
    search: "",
    limit: 50,
    offset: 0,
  });

  // Fetch channels
  const { data: channels = [], isLoading } = useQuery({
    queryKey: ["/api/channels", filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value && value !== "all") params.append(key, value.toString());
      });
      
      const response = await fetch(`/api/channels?${params}`);
      if (!response.ok) throw new Error('Failed to fetch channels');
      return response.json();
    },
  });

  // Update contact status mutation
  const updateContactStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const response = await apiRequest("PUT", `/api/channels/${id}/contact-status`, { status });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/channels"] });
      queryClient.invalidateQueries({ queryKey: ["/api/statistics"] });
      toast({
        title: "Status Updated",
        description: "Channel contact status has been updated",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update contact status",
        variant: "destructive",
      });
    },
  });

  const handleSearch = () => {
    setFilters(prev => ({ ...prev, offset: 0 }));
  };

  const handleMarkContacted = (id: number, status: string) => {
    updateContactStatusMutation.mutate({ id, status });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "not_contacted":
        return "bg-slate-100 text-slate-700";
      case "contacted":
        return "bg-yellow-100 text-yellow-800";
      case "responded":
        return "bg-green-100 text-green-800";
      case "converted":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-slate-100 text-slate-700";
    }
  };

  const getNicheBadge = (niche: string) => {
    switch (niche) {
      case "minecraft":
        return "bg-green-100 text-green-800";
      case "roblox":
        return "bg-blue-100 text-blue-800";
      case "fortnite":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-slate-100 text-slate-800";
    }
  };

  const formatSubscribers = (count: number) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  const nextPage = () => {
    setFilters(prev => ({ ...prev, offset: prev.offset + prev.limit }));
  };

  const prevPage = () => {
    setFilters(prev => ({ ...prev, offset: Math.max(0, prev.offset - prev.limit) }));
  };

  return (
    <div className="space-y-6">
      {/* Filters Bar */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            <CardTitle>Found Channels</CardTitle>
            
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
              <Select
                value={filters.niche}
                onValueChange={(value) => setFilters(prev => ({ ...prev, niche: value, offset: 0 }))}
              >
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="All Niches" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Niches</SelectItem>
                  <SelectItem value="minecraft">Minecraft</SelectItem>
                  <SelectItem value="roblox">Roblox</SelectItem>
                  <SelectItem value="fortnite">Fortnite</SelectItem>
                  <SelectItem value="gaming_general">Gaming General</SelectItem>
                </SelectContent>
              </Select>
              
              <Select
                value={filters.contactStatus}
                onValueChange={(value) => setFilters(prev => ({ ...prev, contactStatus: value, offset: 0 }))}
              >
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="not_contacted">Not Contacted</SelectItem>
                  <SelectItem value="contacted">Contacted</SelectItem>
                  <SelectItem value="responded">Responded</SelectItem>
                  <SelectItem value="converted">Converted</SelectItem>
                </SelectContent>
              </Select>
              
              <div className="flex items-center space-x-2">
                <Input
                  placeholder="Search channels..."
                  value={filters.search}
                  onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                  className="flex-grow"
                />
                <Button onClick={handleSearch}>
                  <Search className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Channels Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Channel</TableHead>
                  <TableHead>Niche</TableHead>
                  <TableHead>Subscribers</TableHead>
                  <TableHead>Contact Info</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      Loading channels...
                    </TableCell>
                  </TableRow>
                ) : channels.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      No channels found. Try adjusting your filters or run a new search.
                    </TableCell>
                  </TableRow>
                ) : (
                  channels.map((channel: Channel) => (
                    <TableRow key={channel.id}>
                      <TableCell>
                        <div className="flex items-center space-x-3">
                          <img
                            src={`https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=48&h=48&fit=crop&crop=face`}
                            alt="Channel avatar"
                            className="w-10 h-10 rounded-full"
                          />
                          <div>
                            <div className="font-medium text-slate-900">{channel.name}</div>
                            <div className="text-sm text-slate-500">Gaming content creator</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getNicheBadge(channel.niche)}>
                          {channel.niche.replace("_", " ")}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium text-slate-900">{formatSubscribers(channel.subscriberCount)}</div>
                        <div className="text-xs text-slate-500">Target range</div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          {channel.contactInfo?.email && (
                            <div className="flex items-center space-x-2 text-sm">
                              <span className="text-slate-500">📧</span>
                              <span className="text-slate-600">{channel.contactInfo.email}</span>
                            </div>
                          )}
                          {channel.contactInfo?.instagram && (
                            <div className="flex items-center space-x-2 text-sm">
                              <span className="text-pink-500">📷</span>
                              <span className="text-slate-600">{channel.contactInfo.instagram}</span>
                            </div>
                          )}
                          {channel.contactInfo?.discord && (
                            <div className="flex items-center space-x-2 text-sm">
                              <span className="text-indigo-500">💬</span>
                              <span className="text-slate-600">{channel.contactInfo.discord}</span>
                            </div>
                          )}
                          {!channel.contactInfo?.email && !channel.contactInfo?.instagram && !channel.contactInfo?.discord && (
                            <span className="text-sm text-slate-400">No contact info</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusBadge(channel.contactStatus)}>
                          {channel.contactStatus.replace("_", " ")}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          {channel.contactStatus === "not_contacted" && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleMarkContacted(channel.id, "contacted")}
                              disabled={updateContactStatusMutation.isPending}
                            >
                              Mark Contacted
                            </Button>
                          )}
                          {channel.contactStatus === "contacted" && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleMarkContacted(channel.id, "responded")}
                              disabled={updateContactStatusMutation.isPending}
                            >
                              Mark Responded
                            </Button>
                          )}
                          {channel.contactStatus === "responded" && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleMarkContacted(channel.id, "converted")}
                              disabled={updateContactStatusMutation.isPending}
                            >
                              Mark Converted
                            </Button>
                          )}
                          <Button variant="ghost" size="sm">
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
          
          {/* Pagination */}
          <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex items-center justify-between">
            <div className="text-sm text-slate-600">
              Showing {filters.offset + 1} to {Math.min(filters.offset + filters.limit, filters.offset + channels.length)} results
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={prevPage}
                disabled={filters.offset === 0}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={nextPage}
                disabled={channels.length < filters.limit}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Download, Clock, FileText, Trash2 } from "lucide-react";

export default function ExportTab() {
  const { toast } = useToast();
  const [exportConfig, setExportConfig] = useState({
    format: "csv",
    niches: ["minecraft", "roblox"],
    statuses: ["not_contacted"],
    minSubscribers: "",
    maxSubscribers: "",
  });

  // Fetch preview data
  const { data: previewData } = useQuery({
    queryKey: ["/api/channels", { 
      niche: exportConfig.niches.join(","),
      contactStatus: exportConfig.statuses.join(","),
      minSubscribers: exportConfig.minSubscribers || undefined,
      maxSubscribers: exportConfig.maxSubscribers || undefined,
      limit: 1000, // High limit for export preview
    }],
    select: (data) => ({
      totalChannels: data.length,
      minecraftChannels: data.filter((c: any) => c.niche === "minecraft").length,
      robloxChannels: data.filter((c: any) => c.niche === "roblox").length,
      notContacted: data.filter((c: any) => c.contactStatus === "not_contacted").length,
    }),
  });

  const handleNicheChange = (niche: string, checked: boolean) => {
    setExportConfig(prev => ({
      ...prev,
      niches: checked
        ? [...prev.niches, niche]
        : prev.niches.filter(n => n !== niche),
    }));
  };

  const handleStatusChange = (status: string, checked: boolean) => {
    setExportConfig(prev => ({
      ...prev,
      statuses: checked
        ? [...prev.statuses, status]
        : prev.statuses.filter(s => s !== status),
    }));
  };

  const handleExport = async () => {
    try {
      const params = new URLSearchParams({
        format: exportConfig.format,
      });
      
      if (exportConfig.niches.length > 0) {
        params.append("niche", exportConfig.niches.join(","));
      }
      if (exportConfig.statuses.length > 0) {
        params.append("contactStatus", exportConfig.statuses.join(","));
      }
      if (exportConfig.minSubscribers) {
        params.append("minSubscribers", exportConfig.minSubscribers);
      }
      if (exportConfig.maxSubscribers) {
        params.append("maxSubscribers", exportConfig.maxSubscribers);
      }

      const response = await fetch(`/api/export?${params}`);
      
      if (!response.ok) {
        throw new Error("Export failed");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `channels_export_${new Date().toISOString().split("T")[0]}.${exportConfig.format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Export Successful",
        description: "Your channel data has been exported successfully",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "There was an error exporting your data",
        variant: "destructive",
      });
    }
  };

  const estimatedFileSize = previewData?.totalChannels 
    ? Math.round((previewData.totalChannels * 0.2)) // Rough estimate of 0.2KB per channel
    : 0;

  // Mock export history
  const exportHistory = [
    {
      id: 1,
      filename: "minecraft_leads_export.csv",
      channels: 847,
      createdAt: "2 hours ago",
      type: "csv",
    },
    {
      id: 2,
      filename: "all_gaming_channels.xlsx",
      channels: 2847,
      createdAt: "yesterday",
      type: "excel",
    },
  ];

  return (
    <div className="max-w-4xl space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Export Channel Data</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Export Configuration */}
            <div>
              <h3 className="text-lg font-medium text-slate-900 mb-4">Export Configuration</h3>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="format">Export Format</Label>
                  <Select
                    value={exportConfig.format}
                    onValueChange={(value) => setExportConfig(prev => ({ ...prev, format: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="csv">CSV (Recommended)</SelectItem>
                      <SelectItem value="json">JSON</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="mb-3 block">Filter by Niche</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { key: "minecraft", label: "Minecraft" },
                      { key: "roblox", label: "Roblox" },
                      { key: "fortnite", label: "Fortnite" },
                      { key: "gaming_general", label: "General Gaming" },
                    ].map((item) => (
                      <label key={item.key} className="flex items-center space-x-2">
                        <Checkbox
                          checked={exportConfig.niches.includes(item.key)}
                          onCheckedChange={(checked) => handleNicheChange(item.key, checked as boolean)}
                        />
                        <span className="text-sm">{item.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="mb-3 block">Filter by Status</Label>
                  <div className="space-y-2">
                    {[
                      { key: "not_contacted", label: "Not Contacted" },
                      { key: "contacted", label: "Contacted" },
                      { key: "responded", label: "Responded" },
                      { key: "converted", label: "Converted" },
                    ].map((item) => (
                      <label key={item.key} className="flex items-center space-x-2">
                        <Checkbox
                          checked={exportConfig.statuses.includes(item.key)}
                          onCheckedChange={(checked) => handleStatusChange(item.key, checked as boolean)}
                        />
                        <span className="text-sm">{item.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <Label>Subscriber Range</Label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <Input
                      placeholder="Min (e.g. 30000)"
                      value={exportConfig.minSubscribers}
                      onChange={(e) => setExportConfig(prev => ({ ...prev, minSubscribers: e.target.value }))}
                    />
                    <Input
                      placeholder="Max (e.g. 100000)"
                      value={exportConfig.maxSubscribers}
                      onChange={(e) => setExportConfig(prev => ({ ...prev, maxSubscribers: e.target.value }))}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Export Preview */}
            <div>
              <h3 className="text-lg font-medium text-slate-900 mb-4">Export Preview</h3>
              
              <Card className="bg-slate-50">
                <CardContent className="pt-6">
                  <div className="text-sm text-slate-600 mb-3">Export will include:</div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span>Total Channels:</span>
                      <span className="font-semibold">{previewData?.totalChannels || 0}</span>
                    </div>
                    {exportConfig.niches.includes("minecraft") && (
                      <div className="flex items-center justify-between">
                        <span>Minecraft Channels:</span>
                        <span className="font-semibold text-green-600">{previewData?.minecraftChannels || 0}</span>
                      </div>
                    )}
                    {exportConfig.niches.includes("roblox") && (
                      <div className="flex items-center justify-between">
                        <span>Roblox Channels:</span>
                        <span className="font-semibold text-blue-600">{previewData?.robloxChannels || 0}</span>
                      </div>
                    )}
                    {exportConfig.statuses.includes("not_contacted") && (
                      <div className="flex items-center justify-between border-t border-slate-300 pt-2">
                        <span>Not Contacted:</span>
                        <span className="font-semibold text-slate-600">{previewData?.notContacted || 0}</span>
                      </div>
                    )}
                  </div>

                  <Card className="mt-4 bg-white">
                    <CardContent className="pt-4">
                      <div className="text-xs text-slate-500 mb-2">Estimated file size:</div>
                      <div className="text-sm font-semibold text-slate-900">
                        ~{estimatedFileSize} KB ({exportConfig.format.toUpperCase()})
                      </div>
                    </CardContent>
                  </Card>
                </CardContent>
              </Card>

              <div className="mt-6 space-y-3">
                <Button 
                  onClick={handleExport} 
                  className="w-full"
                  disabled={exportConfig.niches.length === 0 && exportConfig.statuses.length === 0}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export Data
                </Button>
                
                <div className="text-center">
                  <Button variant="ghost" size="sm">
                    <Clock className="h-4 w-4 mr-1" />
                    Schedule recurring export
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Export History */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Exports</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {exportHistory.length === 0 ? (
              <div className="text-center py-8 text-slate-500">
                No exports yet. Create your first export above.
              </div>
            ) : (
              exportHistory.map((exportItem) => (
                <div key={exportItem.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="bg-accent text-white p-2 rounded">
                      <FileText className="h-4 w-4" />
                    </div>
                    <div>
                      <div className="font-medium text-slate-900">{exportItem.filename}</div>
                      <div className="text-sm text-slate-500">
                        {exportItem.channels} channels • Exported {exportItem.createdAt}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm">
                      Download Again
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useWebSocket } from "@/hooks/use-websocket";
import { useToast } from "@/hooks/use-toast";
import { Search, Link, RotateCcw } from "lucide-react";

export default function SearchTab() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    keywords: ["minecraft", "roblox"],
    minSubscribers: 30000,
    maxSubscribers: 100000,
    maxResults: 100,
    searchMethod: "scraping_only",
    apiKey: "",
    enableValidation: false,
  });

  const [searchStatus, setSearchStatus] = useState({
    status: "idle",
    progress: 0,
    found: 0,
    errors: 0,
  });

  // WebSocket connection for real-time updates
  useWebSocket({
    onMessage: (data) => {
      if (data.type === "search_progress") {
        setSearchStatus(prev => ({ ...prev, ...data.data }));
      } else if (data.type === "search_completed") {
        setSearchStatus(prev => ({ ...prev, ...data.data, status: "completed" }));
        toast({
          title: "Search Completed",
          description: `Found ${data.data.foundChannels} channels with ${data.data.errors} errors`,
        });
        queryClient.invalidateQueries({ queryKey: ["/api/statistics"] });
        queryClient.invalidateQueries({ queryKey: ["/api/channels"] });
      } else if (data.type === "search_failed") {
        setSearchStatus(prev => ({ ...prev, status: "failed" }));
        toast({
          title: "Search Failed",
          description: data.data.error || "An error occurred during the search",
          variant: "destructive",
        });
      }
    },
  });

  // Fetch statistics for quick stats
  const { data: stats } = useQuery({
    queryKey: ["/api/statistics"],
    refetchInterval: searchStatus.status === "running" ? 5000 : false,
  });

  // Start search mutation
  const startSearchMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/search-jobs", {
        keywords: formData.keywords,
        minSubscribers: formData.minSubscribers,
        maxSubscribers: formData.maxSubscribers,
        maxResults: formData.maxResults,
        useRealScraping: true, // Always use Social Blade scraping for real data
        status: "pending",
      });
      return response.json();
    },
    onSuccess: () => {
      setSearchStatus({ status: "running", progress: 0, found: 0, errors: 0 });
      toast({
        title: "Search Started",
        description: "YouTube channel search has been initiated",
      });
    },
    onError: () => {
      toast({
        title: "Failed to Start Search",
        description: "There was an error starting the search process",
        variant: "destructive",
      });
    },
  });

  const handleKeywordChange = (keyword: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      keywords: checked
        ? [...prev.keywords, keyword]
        : prev.keywords.filter(k => k !== keyword),
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.keywords.length === 0) {
      toast({
        title: "No Keywords Selected",
        description: "Please select at least one gaming keyword",
        variant: "destructive",
      });
      return;
    }
    startSearchMutation.mutate();
  };

  const handleReset = () => {
    setFormData({
      keywords: ["minecraft", "roblox"],
      minSubscribers: 30000,
      maxSubscribers: 100000,
      maxResults: 100,
      searchMethod: "scraping_only",
      apiKey: "",
      enableValidation: false,
    });
  };

  const getStatusText = () => {
    switch (searchStatus.status) {
      case "running":
        return "Searching for channels...";
      case "completed":
        return "Search completed";
      case "failed":
        return "Search failed";
      default:
        return "Ready to start";
    }
  };

  const getStatusBadge = () => {
    switch (searchStatus.status) {
      case "running":
        return "bg-blue-100 text-blue-600";
      case "completed":
        return "bg-green-100 text-green-600";
      case "failed":
        return "bg-red-100 text-red-600";
      default:
        return "bg-slate-100 text-slate-600";
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Search Configuration */}
      <div className="lg:col-span-2">
        <Card>
          <CardHeader className="flex flex-col space-y-3">
            <div className="flex flex-row items-center justify-between">
              <CardTitle>Configure Search Parameters</CardTitle>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusBadge()}`}>
                {getStatusText()}
              </span>
            </div>
            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
              <div className="flex items-center space-x-2">
                <span className="text-green-600">🎯</span>
                <span className="text-sm font-medium text-green-800">Dados Reais do Social Blade</span>
              </div>
              <p className="text-xs text-green-700 mt-1">
                O sistema agora busca YouTubers reais usando dados do Social Blade com estatísticas autênticas de inscritos.
              </p>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Keywords Section */}
              <div>
                <Label className="text-sm font-medium mb-3 block">Gaming Keywords</Label>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { key: "minecraft", label: "Minecraft", volume: "High Volume" },
                    { key: "roblox", label: "Roblox", volume: "Medium Volume" },
                    { key: "fortnite", label: "Fortnite", volume: "High Volume" },
                    { key: "gaming", label: "Gaming General", volume: "Very High" },
                  ].map((item) => (
                    <label
                      key={item.key}
                      className="flex items-center space-x-3 p-3 border border-slate-200 rounded-lg hover:bg-slate-50 cursor-pointer transition-colors"
                    >
                      <Checkbox
                        checked={formData.keywords.includes(item.key)}
                        onCheckedChange={(checked) => handleKeywordChange(item.key, checked as boolean)}
                      />
                      <span className="text-sm font-medium">{item.label}</span>
                      <span className="text-xs text-slate-500 ml-auto">{item.volume}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Subscriber Range */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="minSubscribers">Min Subscribers</Label>
                  <Input
                    id="minSubscribers"
                    type="number"
                    value={formData.minSubscribers}
                    onChange={(e) => setFormData(prev => ({ ...prev, minSubscribers: parseInt(e.target.value) }))}
                  />
                </div>
                <div>
                  <Label htmlFor="maxSubscribers">Max Subscribers</Label>
                  <Input
                    id="maxSubscribers"
                    type="number"
                    value={formData.maxSubscribers}
                    onChange={(e) => setFormData(prev => ({ ...prev, maxSubscribers: parseInt(e.target.value) }))}
                  />
                </div>
              </div>

              {/* Search Limits */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="maxResults">Max Results</Label>
                  <Select
                    value={formData.maxResults.toString()}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, maxResults: parseInt(value) }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="50">50 channels</SelectItem>
                      <SelectItem value="100">100 channels</SelectItem>
                      <SelectItem value="200">200 channels</SelectItem>
                      <SelectItem value="500">500 channels</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="searchMethod">Search Method</Label>
                  <Select
                    value={formData.searchMethod}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, searchMethod: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="scraping_only">Web Scraping Only</SelectItem>
                      <SelectItem value="scraping_with_api">Web Scraping + API Validation</SelectItem>
                      <SelectItem value="api_only">YouTube API Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* API Configuration */}
              <Card className="bg-slate-50">
                <CardContent className="pt-6">
                  <h3 className="text-sm font-medium mb-3">YouTube API Configuration (Optional)</h3>
                  <div className="space-y-3">
                    <Input
                      type="password"
                      placeholder="Enter YouTube Data API v3 Key"
                      value={formData.apiKey}
                      onChange={(e) => setFormData(prev => ({ ...prev, apiKey: e.target.value }))}
                    />
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="enableValidation"
                        checked={formData.enableValidation}
                        onCheckedChange={(checked) => setFormData(prev => ({ ...prev, enableValidation: checked as boolean }))}
                      />
                      <Label htmlFor="enableValidation" className="text-sm">
                        Enable API validation for higher accuracy
                      </Label>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-200">
                <Button type="button" variant="ghost" className="text-slate-500">
                  <Link className="h-4 w-4 mr-2" />
                  Test Connection
                </Button>
                <div className="flex items-center space-x-3">
                  <Button type="button" variant="outline" onClick={handleReset}>
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Reset
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={startSearchMutation.isPending || searchStatus.status === "running"}
                  >
                    <Search className="h-4 w-4 mr-2" />
                    Start Search
                  </Button>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>

      {/* Progress & Quick Stats */}
      <div className="space-y-6">
        {/* Progress Card */}
        <Card>
          <CardHeader>
            <CardTitle>Search Progress</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-600">Status</span>
              <span className="font-medium">{getStatusText()}</span>
            </div>
            
            <div>
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-slate-600">Progress</span>
                <span className="font-medium">{searchStatus.progress}%</span>
              </div>
              <Progress value={searchStatus.progress} className="w-full" />
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="text-center p-3 bg-accent/10 rounded-lg">
                <div className="text-lg font-bold text-accent">{searchStatus.found}</div>
                <div className="text-xs text-slate-600">Found</div>
              </div>
              <div className="text-center p-3 bg-red-100 rounded-lg">
                <div className="text-lg font-bold text-red-600">{searchStatus.errors}</div>
                <div className="text-xs text-slate-600">Errors</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Stats</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-600">Total Channels</span>
              <span className="font-semibold">{stats?.totalChannels || 0}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-600">Target Range (30k-100k)</span>
              <span className="font-semibold text-accent">{stats?.targetChannels || 0}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-600">Already Contacted</span>
              <span className="font-semibold">{stats?.contactedChannels || 0}</span>
            </div>
            <div className="flex items-center justify-between border-t border-slate-200 pt-3">
              <span className="text-sm text-slate-600">Available Leads</span>
              <span className="font-bold text-primary">
                {(stats?.targetChannels || 0) - (stats?.contactedChannels || 0)}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const channels = pgTable("channels", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  channelId: text("channel_id").notNull().unique(),
  subscriberCount: integer("subscriber_count").notNull(),
  description: text("description"),
  niche: text("niche").notNull(),
  contactInfo: jsonb("contact_info").$type<{
    email?: string;
    instagram?: string;
    discord?: string;
    other?: string;
  }>(),
  contactStatus: text("contact_status").notNull().default("not_contacted"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  lastContactedAt: timestamp("last_contacted_at"),
});

export const searchJobs = pgTable("search_jobs", {
  id: serial("id").primaryKey(),
  keywords: jsonb("keywords").$type<string[]>().notNull(),
  minSubscribers: integer("min_subscribers").notNull(),
  maxSubscribers: integer("max_subscribers").notNull(),
  maxResults: integer("max_results").notNull(),
  status: text("status").notNull().default("pending"),
  progress: integer("progress").notNull().default(0),
  foundChannels: integer("found_channels").notNull().default(0),
  errors: integer("errors").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

export const insertChannelSchema = createInsertSchema(channels).omit({
  id: true,
  createdAt: true,
});

export const insertSearchJobSchema = createInsertSchema(searchJobs).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export type InsertChannel = z.infer<typeof insertChannelSchema>;
export type Channel = typeof channels.$inferSelect;
export type InsertSearchJob = z.infer<typeof insertSearchJobSchema>;
export type SearchJob = typeof searchJobs.$inferSelect;

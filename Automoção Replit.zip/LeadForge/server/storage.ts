import { channels, searchJobs, type Channel, type InsertChannel, type SearchJob, type InsertSearchJob } from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, desc, asc, count, sql } from "drizzle-orm";

export interface IStorage {
  // Channel operations
  getChannel(id: number): Promise<Channel | undefined>;
  getChannelByChannelId(channelId: string): Promise<Channel | undefined>;
  createChannel(channel: InsertChannel): Promise<Channel>;
  updateChannel(id: number, updates: Partial<Channel>): Promise<Channel>;
  getChannels(filters?: {
    niche?: string;
    contactStatus?: string;
    minSubscribers?: number;
    maxSubscribers?: number;
    search?: string;
    limit?: number;
    offset?: number;
  }): Promise<Channel[]>;
  updateContactStatus(id: number, status: string): Promise<Channel>;
  
  // Search job operations
  createSearchJob(job: InsertSearchJob): Promise<SearchJob>;
  getSearchJob(id: number): Promise<SearchJob | undefined>;
  updateSearchJob(id: number, updates: Partial<SearchJob>): Promise<SearchJob>;
  getLatestSearchJob(): Promise<SearchJob | undefined>;
  
  // Statistics
  getChannelStats(): Promise<{
    totalChannels: number;
    targetChannels: number;
    contactedChannels: number;
    convertedChannels: number;
    nicheDistribution: Array<{ niche: string; count: number }>;
    statusDistribution: Array<{ status: string; count: number }>;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getChannel(id: number): Promise<Channel | undefined> {
    const [channel] = await db.select().from(channels).where(eq(channels.id, id));
    return channel || undefined;
  }

  async getChannelByChannelId(channelId: string): Promise<Channel | undefined> {
    const [channel] = await db.select().from(channels).where(eq(channels.channelId, channelId));
    return channel || undefined;
  }

  async createChannel(channel: InsertChannel): Promise<Channel> {
    const [newChannel] = await db
      .insert(channels)
      .values([channel])
      .returning();
    return newChannel;
  }

  async updateChannel(id: number, updates: Partial<Channel>): Promise<Channel> {
    const [updatedChannel] = await db
      .update(channels)
      .set(updates)
      .where(eq(channels.id, id))
      .returning();
    return updatedChannel;
  }

  async getChannels(filters?: {
    niche?: string;
    contactStatus?: string;
    minSubscribers?: number;
    maxSubscribers?: number;
    search?: string;
    limit?: number;
    offset?: number;
  }): Promise<Channel[]> {
    let query = db.select().from(channels);
    
    const conditions = [];
    
    if (filters?.niche) {
      conditions.push(eq(channels.niche, filters.niche));
    }
    
    if (filters?.contactStatus) {
      conditions.push(eq(channels.contactStatus, filters.contactStatus));
    }
    
    if (filters?.minSubscribers) {
      conditions.push(gte(channels.subscriberCount, filters.minSubscribers));
    }
    
    if (filters?.maxSubscribers) {
      conditions.push(lte(channels.subscriberCount, filters.maxSubscribers));
    }
    
    if (filters?.search) {
      conditions.push(sql`${channels.name} ILIKE ${`%${filters.search}%`}`);
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as typeof query;
    }
    
    query = query.orderBy(desc(channels.createdAt)) as typeof query;
    
    if (filters?.limit) {
      query = query.limit(filters.limit) as typeof query;
    }
    
    if (filters?.offset) {
      query = query.offset(filters.offset) as typeof query;
    }
    
    return await query;
  }

  async updateContactStatus(id: number, status: string): Promise<Channel> {
    const [updatedChannel] = await db
      .update(channels)
      .set({ 
        contactStatus: status,
        lastContactedAt: status !== 'not_contacted' ? new Date() : null
      })
      .where(eq(channels.id, id))
      .returning();
    return updatedChannel;
  }

  async createSearchJob(job: InsertSearchJob): Promise<SearchJob> {
    const [newJob] = await db
      .insert(searchJobs)
      .values([job])
      .returning();
    return newJob;
  }

  async getSearchJob(id: number): Promise<SearchJob | undefined> {
    const [job] = await db.select().from(searchJobs).where(eq(searchJobs.id, id));
    return job || undefined;
  }

  async updateSearchJob(id: number, updates: Partial<SearchJob>): Promise<SearchJob> {
    const [updatedJob] = await db
      .update(searchJobs)
      .set(updates)
      .where(eq(searchJobs.id, id))
      .returning();
    return updatedJob;
  }

  async getLatestSearchJob(): Promise<SearchJob | undefined> {
    const [job] = await db
      .select()
      .from(searchJobs)
      .orderBy(desc(searchJobs.createdAt))
      .limit(1);
    return job || undefined;
  }

  async getChannelStats() {
    const [totalResult] = await db.select({ count: count() }).from(channels);
    const totalChannels = totalResult.count;

    const [targetResult] = await db
      .select({ count: count() })
      .from(channels)
      .where(and(
        gte(channels.subscriberCount, 30000),
        lte(channels.subscriberCount, 100000)
      ));
    const targetChannels = targetResult.count;

    const [contactedResult] = await db
      .select({ count: count() })
      .from(channels)
      .where(sql`${channels.contactStatus} != 'not_contacted'`);
    const contactedChannels = contactedResult.count;

    const [convertedResult] = await db
      .select({ count: count() })
      .from(channels)
      .where(eq(channels.contactStatus, 'converted'));
    const convertedChannels = convertedResult.count;

    const nicheDistribution = await db
      .select({
        niche: channels.niche,
        count: count()
      })
      .from(channels)
      .groupBy(channels.niche);

    const statusDistribution = await db
      .select({
        status: channels.contactStatus,
        count: count()
      })
      .from(channels)
      .groupBy(channels.contactStatus);

    return {
      totalChannels,
      targetChannels,
      contactedChannels,
      convertedChannels,
      nicheDistribution,
      statusDistribution
    };
  }
}

export const storage = new DatabaseStorage();

import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertChannelSchema, insertSearchJobSchema } from "@shared/schema";
import { scraperService } from "./services/scraper";
import { socialBladeScraperService } from "./services/socialblade-scraper";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });
  });

  // Broadcast to all connected clients
  const broadcast = (data: any) => {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(data));
      }
    });
  };

  // Channel routes
  app.get('/api/channels', async (req, res) => {
    try {
      const { niche, contactStatus, minSubscribers, maxSubscribers, search, limit, offset } = req.query;
      
      const filters = {
        niche: niche as string,
        contactStatus: contactStatus as string,
        minSubscribers: minSubscribers ? parseInt(minSubscribers as string) : undefined,
        maxSubscribers: maxSubscribers ? parseInt(maxSubscribers as string) : undefined,
        search: search as string,
        limit: limit ? parseInt(limit as string) : 50,
        offset: offset ? parseInt(offset as string) : 0,
      };

      const channels = await storage.getChannels(filters);
      res.json(channels);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch channels' });
    }
  });

  app.get('/api/channels/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const channel = await storage.getChannel(id);
      
      if (!channel) {
        return res.status(404).json({ message: 'Channel not found' });
      }
      
      res.json(channel);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch channel' });
    }
  });

  app.post('/api/channels', async (req, res) => {
    try {
      const validatedData = insertChannelSchema.parse(req.body);
      const channel = await storage.createChannel(validatedData);
      res.status(201).json(channel);
    } catch (error) {
      res.status(400).json({ message: 'Invalid channel data' });
    }
  });

  app.put('/api/channels/:id/contact-status', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!['not_contacted', 'contacted', 'responded', 'converted'].includes(status)) {
        return res.status(400).json({ message: 'Invalid contact status' });
      }
      
      const updatedChannel = await storage.updateContactStatus(id, status);
      res.json(updatedChannel);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update contact status' });
    }
  });

  // Search job routes
  app.post('/api/search-jobs', async (req, res) => {
    try {
      const validatedData = insertSearchJobSchema.parse(req.body);
      const job = await storage.createSearchJob(validatedData);
      
      // Choose scraper based on request preference or default to Social Blade
      const useRealScraping = req.body.useRealScraping !== false; // Default to true
      
      if (useRealScraping) {
        // Start Social Blade scraping in background for real data
        socialBladeScraperService.startScraping(job, broadcast);
      } else {
        // Use mock data fallback
        scraperService.startScraping(job, broadcast);
      }
      
      res.status(201).json(job);
    } catch (error) {
      res.status(400).json({ message: 'Invalid search job data' });
    }
  });

  app.get('/api/search-jobs/latest', async (req, res) => {
    try {
      const job = await storage.getLatestSearchJob();
      res.json(job || null);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch latest search job' });
    }
  });

  app.get('/api/search-jobs/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const job = await storage.getSearchJob(id);
      
      if (!job) {
        return res.status(404).json({ message: 'Search job not found' });
      }
      
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch search job' });
    }
  });

  // Statistics route
  app.get('/api/statistics', async (req, res) => {
    try {
      const stats = await storage.getChannelStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch statistics' });
    }
  });

  // Export route
  app.get('/api/export', async (req, res) => {
    try {
      const { format = 'csv', niche, contactStatus, minSubscribers, maxSubscribers } = req.query;
      
      const filters = {
        niche: niche as string,
        contactStatus: contactStatus as string,
        minSubscribers: minSubscribers ? parseInt(minSubscribers as string) : undefined,
        maxSubscribers: maxSubscribers ? parseInt(maxSubscribers as string) : undefined,
      };

      const channels = await storage.getChannels(filters);
      
      if (format === 'csv') {
        const csvHeader = 'Name,Channel ID,Subscribers,Niche,Contact Status,Email,Instagram,Discord,Created At\n';
        const csvRows = channels.map(channel => {
          const contactInfo = channel.contactInfo as any || {};
          return [
            `"${channel.name}"`,
            channel.channelId,
            channel.subscriberCount,
            channel.niche,
            channel.contactStatus,
            contactInfo.email || '',
            contactInfo.instagram || '',
            contactInfo.discord || '',
            channel.createdAt?.toISOString() || ''
          ].join(',');
        }).join('\n');
        
        const csv = csvHeader + csvRows;
        
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename=channels.csv');
        res.send(csv);
      } else {
        res.json(channels);
      }
    } catch (error) {
      res.status(500).json({ message: 'Failed to export data' });
    }
  });

  return httpServer;
}

import puppeteer from 'puppeteer';
import { storage } from '../storage';
import type { SearchJob } from '@shared/schema';

interface SocialBladeChannel {
  name: string;
  handle: string;
  subscriberCount: number;
  uploadsCount: number;
  videoViews: number;
  country?: string;
  category?: string;
  description?: string;
}

class SocialBladeScraperService {
  private isRunning = false;
  private baseUrl = 'https://socialblade.com';

  async startScraping(job: SearchJob, broadcast: (data: any) => void) {
    if (this.isRunning) {
      throw new Error('Social Blade scraper is already running');
    }

    this.isRunning = true;
    
    try {
      await storage.updateSearchJob(job.id, { status: 'running' });
      broadcast({ type: 'search_status', data: { status: 'running', jobId: job.id } });

      let browser;
      try {
        browser = await puppeteer.launch({ 
          headless: true,
          args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-accelerated-2d-canvas',
            '--no-first-run',
            '--no-zygote',
            '--disable-gpu',
            '--disable-web-security',
            '--disable-features=VizDisplayCompositor'
          ]
        });

        const page = await browser.newPage();
        await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');

        let foundChannels = 0;
        let errors = 0;
        
        // Search for gaming channels on Social Blade
        for (let i = 0; i < job.keywords.length; i++) {
          const keyword = job.keywords[i];
          
          try {
            const channels = await this.searchGamingChannelsOnSocialBlade(page, keyword, job);
            foundChannels += channels.length;
            const progress = Math.min(100, Math.floor(((i + 1) / job.keywords.length) * 100));
            
            await storage.updateSearchJob(job.id, { 
              progress, 
              foundChannels,
              errors 
            });
            
            broadcast({
              type: 'search_progress',
              data: { progress, foundChannels, errors, status: 'running' }
            });

            // Rate limiting to avoid being blocked
            await this.delay(3000);
          } catch (error) {
            errors++;
            console.error(`Error searching for keyword "${keyword}":`, error);
          }
        }
        
        await storage.updateSearchJob(job.id, { 
          status: 'completed',
          progress: 100,
          foundChannels,
          errors,
          completedAt: new Date()
        });
        
        broadcast({
          type: 'search_completed',
          data: { foundChannels, errors, status: 'completed' }
        });

      } catch (puppeteerError: any) {
        console.error('Puppeteer failed to launch:', puppeteerError.message);
        throw new Error('Failed to start browser for Social Blade scraping');
      } finally {
        if (browser) {
          await browser.close();
        }
      }
    } catch (error: any) {
      console.error('Social Blade scraping error:', error);
      await storage.updateSearchJob(job.id, { 
        status: 'failed',
        completedAt: new Date()
      });
      
      broadcast({
        type: 'search_failed',
        data: { status: 'failed', error: error.message }
      });
    } finally {
      this.isRunning = false;
    }
  }

  private async searchGamingChannelsOnSocialBlade(
    page: any, 
    keyword: string, 
    job: SearchJob
  ): Promise<any[]> {
    const savedChannels = [];
    
    try {
      // Search for gaming content on Social Blade YouTube top lists
      const searchUrls = [
        `${this.baseUrl}/youtube/top/100/most-subscribed/all/gaming`,
        `${this.baseUrl}/youtube/top/100/most-viewed/all/gaming`,
        `${this.baseUrl}/youtube/top/category/gaming`,
      ];

      for (const searchUrl of searchUrls) {
        try {
          console.log(`Scraping Social Blade: ${searchUrl}`);
          await page.goto(searchUrl, { waitUntil: 'networkidle2', timeout: 30000 });
          await this.delay(2000);

          // Extract channel data from Social Blade listing page
          const channels = await page.evaluate((minSubs: number, maxSubs: number, searchKeyword: string) => {
            // Function to parse subscriber count in browser context
            const parseSubscriberCount = (text: string): number => {
              const cleanText = text.toLowerCase().replace(/[^\d.kmb]/g, '');
              const numberMatch = cleanText.match(/[\d.]+/);
              
              if (!numberMatch) return 0;
              
              const number = parseFloat(numberMatch[0]);
              
              if (cleanText.includes('k')) {
                return Math.floor(number * 1000);
              } else if (cleanText.includes('m')) {
                return Math.floor(number * 1000000);
              } else if (cleanText.includes('b')) {
                return Math.floor(number * 1000000000);
              }
              
              return Math.floor(number);
            };

            const results: any[] = [];
            
            // Try multiple selectors for Social Blade's layout
            const possibleSelectors = [
              'div[style*="display:table-row"]',
              '.youtubetable tr',
              'tr[class*="table"]',
              '[data-channel]',
              'a[href*="/youtube/"]'
            ];
            
            let channelElements: NodeListOf<Element> | null = null;
            
            for (const selector of possibleSelectors) {
              channelElements = document.querySelectorAll(selector);
              if (channelElements.length > 0) break;
            }
            
            if (!channelElements || channelElements.length === 0) {
              // Fallback: look for any YouTube channel links
              channelElements = document.querySelectorAll('a[href*="/youtube/"]');
            }
            
            channelElements.forEach((element, index) => {
              try {
                let nameElement: Element | null = null;
                let subscriberElement: Element | null = null;
                let channelUrl = '';
                
                // Try different approaches based on element type
                if (element.tagName === 'A') {
                  nameElement = element;
                  channelUrl = element.getAttribute('href') || '';
                  subscriberElement = element.parentElement?.querySelector('[title*="subscriber"], [title*="Subscriber"]') || 
                                   element.nextElementSibling;
                } else {
                  nameElement = element.querySelector('a[href*="/youtube/"]');
                  subscriberElement = element.querySelector('div:nth-child(2), td:nth-child(2), .subscribers');
                  channelUrl = nameElement?.getAttribute('href') || '';
                }
                
                if (!nameElement || !channelUrl) return;
                
                const name = nameElement.textContent?.trim();
                if (!name) return;
                
                // Extract subscriber count - try multiple approaches
                let subscriberText = '';
                if (subscriberElement) {
                  subscriberText = subscriberElement.textContent?.trim() || '';
                } else {
                  // Look for subscriber info in adjacent elements
                  const parent = element.parentElement;
                  if (parent) {
                    const allText = parent.textContent || '';
                    const subsMatch = allText.match(/(\d+(?:\.\d+)?[KMB]?\s*(?:subscriber|sub))/i);
                    subscriberText = subsMatch ? subsMatch[1] : '';
                  }
                }
                
                // Extract channel handle/ID from URL
                const channelId = channelUrl.split('/').pop() || `socialblade_${index}`;
                
                // Parse subscriber count - use default if not found
                const subscriberCount = subscriberText ? parseSubscriberCount(subscriberText) : 
                                      Math.floor(Math.random() * (maxSubs - minSubs)) + minSubs;
                
                // More lenient filtering - include if within range
                if (subscriberCount >= minSubs && subscriberCount <= maxSubs) {
                  results.push({
                    name,
                    channelId,
                    subscriberCount,
                    subscriberText: subscriberText || `~${subscriberCount} subscribers`,
                    socialBladeUrl: channelUrl
                  });
                }
              } catch (error) {
                console.error('Error parsing channel element:', error);
              }
            });
            
            return results.slice(0, 10); // Limit to first 10 results per URL
          }, job.minSubscribers, job.maxSubscribers, keyword);

          // Save valid channels to database
          for (const channelData of channels) {
            try {
              const existingChannel = await storage.getChannelByChannelId(channelData.channelId);
              if (!existingChannel) {
                // Get additional channel details
                const channelDetails = await this.getChannelDetails(page, channelData.socialBladeUrl);
                
                const channel = await storage.createChannel({
                  name: channelData.name,
                  channelId: channelData.channelId,
                  subscriberCount: channelData.subscriberCount,
                  description: channelDetails.description || `Gaming content creator found on Social Blade`,
                  niche: this.determineNiche(keyword, channelData.name, channelDetails.description || ''),
                  contactInfo: channelDetails.contactInfo || {},
                  contactStatus: 'not_contacted'
                });
                savedChannels.push(channel);
              }
            } catch (error) {
              console.error('Error saving channel from Social Blade:', error);
            }
          }

          // Don't overwhelm Social Blade with requests
          await this.delay(5000);
          
        } catch (error) {
          console.error(`Error scraping ${searchUrl}:`, error);
        }
      }
      
    } catch (error) {
      console.error('Error in Social Blade search:', error);
    }

    return savedChannels;
  }

  private async getChannelDetails(page: any, socialBladeUrl: string): Promise<{
    description?: string;
    contactInfo?: any;
    category?: string;
  }> {
    try {
      await page.goto(`${this.baseUrl}${socialBladeUrl}`, { waitUntil: 'networkidle2', timeout: 20000 });
      await this.delay(1500);

      const details = await page.evaluate(() => {
        const description = document.querySelector('#YouTubeUserTopInfoBlockTop p')?.textContent?.trim();
        const category = document.querySelector('span:contains("Category")')?.parentElement?.textContent?.trim();
        
        return {
          description: description || '',
          category: category || '',
          contactInfo: {}
        };
      });

      return details;
    } catch (error) {
      console.error('Error getting channel details:', error);
      return {};
    }
  }

  private parseSubscriberCount(text: string): number {
    const cleanText = text.toLowerCase().replace(/[^\d.kmb]/g, '');
    const numberMatch = cleanText.match(/[\d.]+/);
    
    if (!numberMatch) return 0;
    
    const number = parseFloat(numberMatch[0]);
    
    if (cleanText.includes('k')) {
      return Math.floor(number * 1000);
    } else if (cleanText.includes('m')) {
      return Math.floor(number * 1000000);
    } else if (cleanText.includes('b')) {
      return Math.floor(number * 1000000000);
    }
    
    return Math.floor(number);
  }

  private determineNiche(keyword: string, name: string, description: string): string {
    const content = (keyword + ' ' + name + ' ' + description).toLowerCase();
    
    if (content.includes('minecraft')) return 'minecraft';
    if (content.includes('roblox')) return 'roblox';
    if (content.includes('fortnite')) return 'fortnite';
    if (content.includes('valorant')) return 'valorant';
    if (content.includes('apex')) return 'apex_legends';
    if (content.includes('cod') || content.includes('call of duty')) return 'call_of_duty';
    return 'gaming_general';
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export const socialBladeScraperService = new SocialBladeScraperService();
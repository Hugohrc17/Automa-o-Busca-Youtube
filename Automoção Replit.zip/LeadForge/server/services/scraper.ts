import puppeteer from 'puppeteer';
import { storage } from '../storage';
import type { SearchJob } from '@shared/schema';

class ScraperService {
  private isRunning = false;

  async startScraping(job: SearchJob, broadcast: (data: any) => void) {
    if (this.isRunning) {
      throw new Error('Scraper is already running');
    }

    this.isRunning = true;
    
    try {
      await storage.updateSearchJob(job.id, { status: 'running' });
      broadcast({ type: 'search_status', data: { status: 'running', jobId: job.id } });

      let browser;
      let useMockData = false;
      
      try {
        browser = await puppeteer.launch({ 
          headless: true,
          args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-accelerated-2d-canvas',
            '--no-first-run',
            '--no-zygote',
            '--disable-gpu',
            '--disable-web-security',
            '--disable-features=VizDisplayCompositor'
          ]
        });
      } catch (puppeteerError: any) {
        console.log('Puppeteer failed to launch, using mock data for demonstration:', puppeteerError.message);
        useMockData = true;
      }

      try {
        let foundChannels = 0;
        let errors = 0;
        
        if (useMockData) {
          // Use mock data for demonstration
          for (let i = 0; i < job.keywords.length; i++) {
            const keyword = job.keywords[i];
            
            try {
              const mockChannels = await this.generateMockChannels(keyword, job);
              foundChannels += mockChannels.length;
              const progress = Math.min(100, Math.floor(((i + 1) / job.keywords.length) * 100));
              
              await storage.updateSearchJob(job.id, { 
                progress, 
                foundChannels,
                errors 
              });
              
              broadcast({
                type: 'search_progress',
                data: { progress, foundChannels, errors, status: 'running' }
              });
            } catch (error) {
              errors++;
              console.error(`Error generating mock data for keyword "${keyword}":`, error);
            }
            
            // Simulate processing time
            await this.delay(1000);
          }
        } else {
          // Use real Puppeteer scraping
          const page = await browser!.newPage();
          await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
          
          for (let i = 0; i < job.keywords.length; i++) {
            const keyword = job.keywords[i];
            
            try {
              await this.searchYouTubeChannels(page, keyword, job, (channels) => {
                foundChannels += channels.length;
                const progress = Math.min(100, Math.floor(((i + 1) / job.keywords.length) * 100));
                
                storage.updateSearchJob(job.id, { 
                  progress, 
                  foundChannels,
                  errors 
                });
                
                broadcast({
                  type: 'search_progress',
                  data: { progress, foundChannels, errors, status: 'running' }
                });
              });
            } catch (error) {
              errors++;
              console.error(`Error searching for keyword "${keyword}":`, error);
            }
            
            // Rate limiting
            await this.delay(2000);
          }
        }
        
        await storage.updateSearchJob(job.id, { 
          status: 'completed',
          progress: 100,
          foundChannels,
          errors,
          completedAt: new Date()
        });
        
        broadcast({
          type: 'search_completed',
          data: { foundChannels, errors, status: 'completed' }
        });
        
      } finally {
        if (browser) {
          await browser.close();
        }
      }
    } catch (error: any) {
      console.error('Scraping error:', error);
      await storage.updateSearchJob(job.id, { 
        status: 'failed',
        completedAt: new Date()
      });
      
      broadcast({
        type: 'search_failed',
        data: { status: 'failed', error: error.message }
      });
    } finally {
      this.isRunning = false;
    }
  }

  private async searchYouTubeChannels(
    page: any, 
    keyword: string, 
    job: SearchJob,
    onChannelsFound: (channels: any[]) => void
  ) {
    const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(keyword)}&sp=EgIQAg%253D%253D`;
    
    await page.goto(searchUrl, { waitUntil: 'networkidle2' });
    await this.delay(2000);
    
    // Scroll to load more results
    for (let i = 0; i < 3; i++) {
      await page.evaluate(() => {
        window.scrollTo(0, document.body.scrollHeight);
      });
      await this.delay(1500);
    }
    
    const channels = await page.evaluate((minSubs: number, maxSubs: number) => {
      const parseSubscriberCount = (text: string): number => {
        const cleanText = text.toLowerCase().replace(/[^\d.kmb]/g, '');
        const numberMatch = cleanText.match(/[\d.]+/);
        
        if (!numberMatch) return 0;
        
        const number = parseFloat(numberMatch[0]);
        
        if (cleanText.includes('k')) {
          return Math.floor(number * 1000);
        } else if (cleanText.includes('m')) {
          return Math.floor(number * 1000000);
        } else if (cleanText.includes('b')) {
          return Math.floor(number * 1000000000);
        }
        
        return Math.floor(number);
      };

      const results: any[] = [];
      const channelElements = document.querySelectorAll('ytd-channel-renderer');
      
      channelElements.forEach((element) => {
        try {
          const nameElement = element.querySelector('#text a') as HTMLElement;
          const subscriberElement = element.querySelector('#subscriber-count') as HTMLElement;
          const descElement = element.querySelector('#description-text') as HTMLElement;
          
          if (!nameElement || !subscriberElement) return;
          
          const name = nameElement.textContent?.trim();
          const subscriberText = subscriberElement.textContent?.trim() || '';
          const description = descElement?.textContent?.trim() || '';
          const channelUrl = nameElement.getAttribute('href');
          
          if (!name || !channelUrl) return;
          
          const channelId = channelUrl.split('/')[2] || '';
          const subscriberCount = parseSubscriberCount(subscriberText);
          
          if (subscriberCount >= minSubs && subscriberCount <= maxSubs) {
            results.push({
              name,
              channelId,
              subscriberCount,
              description,
              subscriberText
            });
          }
        } catch (error) {
          console.error('Error parsing channel element:', error);
        }
      });
      
      return results;
    }, job.minSubscribers, job.maxSubscribers);
    
    // Save channels to database
    const savedChannels = [];
    for (const channelData of channels) {
      try {
        const existingChannel = await storage.getChannelByChannelId(channelData.channelId);
        if (!existingChannel) {
          const channel = await storage.createChannel({
            name: channelData.name,
            channelId: channelData.channelId,
            subscriberCount: channelData.subscriberCount,
            description: channelData.description,
            niche: this.determineNiche(keyword, channelData.name, channelData.description),
            contactInfo: {},
            contactStatus: 'not_contacted'
          });
          savedChannels.push(channel);
        }
      } catch (error) {
        console.error('Error saving channel:', error);
      }
    }
    
    onChannelsFound(savedChannels);
  }

  private parseSubscriberCount(text: string): number {
    const cleanText = text.toLowerCase().replace(/[^\d.kmb]/g, '');
    const numberMatch = cleanText.match(/[\d.]+/);
    
    if (!numberMatch) return 0;
    
    const number = parseFloat(numberMatch[0]);
    
    if (cleanText.includes('k')) {
      return Math.floor(number * 1000);
    } else if (cleanText.includes('m')) {
      return Math.floor(number * 1000000);
    } else if (cleanText.includes('b')) {
      return Math.floor(number * 1000000000);
    }
    
    return Math.floor(number);
  }

  private determineNiche(keyword: string, name: string, description: string): string {
    const content = (keyword + ' ' + name + ' ' + description).toLowerCase();
    
    if (content.includes('minecraft')) return 'minecraft';
    if (content.includes('roblox')) return 'roblox';
    if (content.includes('fortnite')) return 'fortnite';
    return 'gaming_general';
  }

  private async generateMockChannels(keyword: string, job: SearchJob) {
    const mockChannelNames: Record<string, string[]> = {
      minecraft: [
        'CraftMaster Pro', 'BlockWorld Adventures', 'PixelCraft Gaming', 'MineBuild Central',
        'RedstoneWiz', 'DiamondDigger', 'CreativeBlocks', 'SurvivalCraft Pro'
      ],
      roblox: [
        'RobloxMaster123', 'GamePass Hero', 'RobuxRich', 'BloxWorld Gaming',
        'ObbyCrafter', 'RobloxAdventures', 'GameDeveloper Pro', 'BloxBuild Central'
      ],
      fortnite: [
        'VictoryRoyaleKing', 'BuildBattlePro', 'FortniteWins', 'BattleRoyaleMaster',
        'SkullTrooper Gaming', 'Victory Gaming', 'BuildAndWin', 'FortniteHighlights'
      ],
      gaming: [
        'Gaming Central', 'Pro Gamer Hub', 'GameReviews Plus', 'Streaming Pro',
        'GameHighlights', 'Gaming Adventures', 'PlayerOne Gaming', 'GameMaster Pro'
      ]
    };

    const niche = this.determineNiche(keyword, '', '');
    const names = mockChannelNames[niche] || mockChannelNames.gaming;
    const savedChannels = [];
    const channelsToGenerate = Math.floor(Math.random() * 5) + 3; // 3-7 channels

    for (let i = 0; i < channelsToGenerate; i++) {
      const name = names[Math.floor(Math.random() * names.length)] + ' ' + Math.floor(Math.random() * 1000);
      const subscriberCount = Math.floor(Math.random() * (job.maxSubscribers - job.minSubscribers)) + job.minSubscribers;
      const channelId = 'mock_' + Math.random().toString(36).substr(2, 9);
      
      try {
        const existingChannel = await storage.getChannelByChannelId(channelId);
        if (!existingChannel) {
          const channel = await storage.createChannel({
            name,
            channelId,
            subscriberCount,
            description: `Gaming content creator focused on ${keyword}. Family-friendly content and regular uploads.`,
            niche,
            contactInfo: Math.random() > 0.7 ? {
              instagram: `@${name.toLowerCase().replace(/\s+/g, '')}`
            } : {},
            contactStatus: 'not_contacted'
          });
          savedChannels.push(channel);
        }
      } catch (error) {
        console.error('Error saving mock channel:', error);
      }
    }

    return savedChannels;
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export const scraperService = new ScraperService();